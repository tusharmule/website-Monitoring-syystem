package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ResetPassword
 */
@WebServlet("/ResetPassword")
public class ResetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
   		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String uname=request.getParameter("uname");
		String password=request.getParameter("password");
		String ConfirmPassword=request.getParameter("cnfpwd");
		
		System.out.println("Username: "+uname);
		System.out.println("Password; "+password);
		System.out.println("ConfirmPassword:"+ConfirmPassword);
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Found");
			Connection connection=null;
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/websitemonitoring", "root", "root");
			System.out.println("Database connected");
			Statement statement=connection.createStatement();
			String query=("update users set password='"+ConfirmPassword+"' where Username='"+uname+"'");
			statement.executeUpdate(query);
			System.out.println("data updated");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('password update Sucessfully...');");
			out.println("location='index.jsp';");
			out.println("</script>");
   	}
		catch(Exception e) {
			System.out.println(e);
		}

}
}