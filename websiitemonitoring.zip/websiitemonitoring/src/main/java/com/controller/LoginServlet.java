package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String uname=request.getParameter("uname");
		String password=request.getParameter("password");
		
		System.out.println("Username: "+uname);
		System.out.println("Password: "+password);
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Found");
			Connection connection=null;
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/websitemonitoring", "root", "root");
			System.out.println("Database connected");
			Statement statement=connection.createStatement();
			ResultSet rs=statement.executeQuery("select * from users where Username='"+uname+"' and Password='"+password+"'");
			System.out.println("Data Inserted");
			//int i=rs.getFetchSize();
			int i = 0;
			while(rs.next()) {
			    i++;
			}
			System.out.println(i);
			if(i>0)
				{
				out.println("<script type=\"text/javascript\">");
				out.println("location='mainpage.jsp';");
				out.println("</script>");
				}
			else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Username and password incorerect...');");
				out.println("location='index.jsp';");
				out.println("</script>");
			}
			
	}
		catch(Exception e) {
			System.out.println(e);
		}
}
}